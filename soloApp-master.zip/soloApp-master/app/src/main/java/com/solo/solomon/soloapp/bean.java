package com.solo.solomon.soloapp;

import android.app.Application;

public class bean extends Application {

    String id = "";
    String email = "";
    String name = "";

}
